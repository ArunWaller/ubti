<?php
namespace W3TC;

if ( !defined( 'W3TC' ) )
	die();

?>
<p>
    Google Page Speed score is not available.
</p>
<p>
	Please follow the directions
    found in the Miscellanous settings box on the
    <a href="admin.php?page=w3tc_general">General Settings</a> tab.
</p>
