<?php
namespace W3TC;

if ( !defined( 'W3TC' ) )
	die();

?>
<div class="wrapper">
    Not configured
</div>
