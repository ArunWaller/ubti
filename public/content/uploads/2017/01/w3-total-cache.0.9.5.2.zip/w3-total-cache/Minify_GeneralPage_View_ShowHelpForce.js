jQuery(function() {
  w3tc_show_minify_help();
});
